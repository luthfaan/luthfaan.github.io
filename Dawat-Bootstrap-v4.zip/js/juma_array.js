var source = document.getElementById("audio_array").innerHTML;

var template = Handlebars.compile(source);

var audioData = template({
audio_juma: [
{title: "Kasbi Aur Wahbi Cheezain (Juma)",
src: "http://dawat-e-hidayat.org/audio/urdu/juma/j9_kasabi_aur_wahbi_cheezai.mp3",
date: "N/A",
place: "N/A",
time: "17m10s"
},
{title: "Hazrat Luqman Alaihissalam Ki Nasihat - (Juma)",
src: "http://dawat-e-hidayat.org/audio/urdu/juma/j8_hazrat_luqman_as_ki_nasihat.mp3",
date: "N/A",
place: "Chennai, India",
time: "10m36s"
},
{title: "Azmat e Rasool - (Juma)",
src: "http://dawat-e-hidayat.org/audio/urdu/juma/j7_azmat_rasool_sa.mp3",
date: "N/A",
place: "Chennai, India",
time: "13m35s"
},
{title: "Aulad Ko Nasihat - (Juma)",
src: "http://dawat-e-hidayat.org/audio/urdu/juma/j6_farzant_ku_nasihat.mp3",
date: "N/A",
place: "Chennai, India",
time: "15m47s"
},
{title: "Islami Mahiney - (Juma)",
src: "http://dawat-e-hidayat.org/audio/urdu/juma/j5_islami_mahiney.mp3",
date: "N/A",
place: "Chennai, India",
time: "14m35s"
},
{title: "Periamet Masjid - (Juma)",
src: "http://dawat-e-hidayat.org/audio/urdu/juma/j4_periamet_%20juma_bayan.mp3",
date: "N/A",
place: "Chennai, India",
time: "17m16s"
},
{title: "Tazkirat-ul-Anbiya - (Juma)",
src: "http://dawat-e-hidayat.org/audio/urdu/juma/j3_tazikra_e_anbiya.mp3",
date: "N/A",
place: "Chennai, India",
time: "13m38s"
},
{title: "Walidain Ke Huqooq - (Juma)",
src: "http://dawat-e-hidayat.org/audio/urdu/juma/j2_walidain_ke_huqooq.mp3",
date: "N/A",
place: "Chennai, India",
time: "18m15s"
},
{title: "Aqeeda Ki Haisiyat - (Juma)",
src: "http://dawat-e-hidayat.org/audio/urdu/juma/j1_aqeeda_ki_haiseyat.mp3",
date: "N/A",
place: "Chennai, India",
time: "19m27s"
}
]
});

document.getElementById("content").innerHTML += audioData;